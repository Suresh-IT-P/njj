---
name: Obsidian Telemetry
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#343944'
  surface-container-lowest: '#090e17'
  surface-container-low: '#171c25'
  surface-container: '#1b2029'
  surface-container-high: '#252a34'
  surface-container-highest: '#30353f'
  on-surface: '#dee2f0'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dee2f0'
  inverse-on-surface: '#2c303b'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#adc6ff'
  on-tertiary: '#002e6a'
  tertiary-container: '#71a1ff'
  on-tertiary-container: '#00367a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#0f131d'
  on-background: '#dee2f0'
  surface-variant: '#30353f'
  telemetry-emerald: '#10b981'
  telemetry-cyan: '#06b6d4'
  live-radar-ping: '#ef4444'
  surface-obsidian: '#0a0f18'
  surface-slate-base: '#0f172a'
  surface-slate-elevated: '#1e293b'
  border-glass: rgba(255, 255, 255, 0.08)
  border-glass-active: rgba(16, 185, 129, 0.35)
  text-primary: '#f8fafc'
  text-muted: '#94a3b8'
  status-warning: '#f59e0b'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  metric-kpi:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  code-tabular:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  eyebrow-badge:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system elevates enterprise mobility infrastructure from administrative overhead into a high-precision Network Operations Center (NOC) aesthetic. Drawing from dark glassmorphic engineering interfaces and high-density telemetry displays, it positions modern fleet automation as mission-critical command technology.

### Brand Personality & Emotional Impact
- **Surgical Precision:** Every component conveys sub-second reactivity, strict operational reliability, and real-time ledger accuracy.
- **Mission-Critical Authority:** Evokes the poise of an aerospace or autonomous dispatch command station; no playful frivolity, only disciplined performance.
- **Electric Acceleration:** Vibrant energetic teal and emerald accents cut through obsidian depths, signifying active vehicle streams, instant ping responses, and live route optimization.

### Design Movement: Dark Glassmorphic Modernism
The visual architecture pairs deep obsidian canvas tiers with hairline translucent glass panels, luminous border highlights, and tabular data density. Soft, localized cyan/emerald back-glows direct visual priority, while strict grid lines maintain institutional clarity across complex multi-portal interfaces.

## Colors

The palette is tuned specifically for low-light enterprise dispatch and NOC monitoring environments, replacing washed-out corporate neutrals with high-contrast tactical layers.

### Key Roles
- **Primary (`#10b981` - Telemetry Emerald):** Dedicated to verified states, active drivers, sub-second latency markers, primary CTA triggers, and healthy system pulses.
- **Secondary (`#06b6d4` - Telemetry Cyan):** Used for navigation traces, geofence pathways, data visualization splines, and interactive tab selections.
- **Tertiary (`#3b82f6` - Electric Indigo):** Reserved for system infrastructure tiers, API layers, and platform configuration meta-tokens.
- **Neutral (`#0a0f18` - Deep Obsidian):** The foundational substrate that eliminates screen glare while allowing micro-indicators and status pills to pop effortlessly.

### Semantic Status Colors
- **Live Dispatch Stream (`#ef4444`):** Real-time WebSocket connectivity beacon and active ride emergency countdowns.
- **Transit Lifecycle Signals:**
  - *Searching:* Cyan pulse (`#06b6d4`)
  - *Assigned / Arriving:* Emerald ring (`#10b981`)
  - *En Route:* Sky luminous tint (`#38bdf8`)
  - *Pending Attention / Tariffs:* Amber amber tone (`#f59e0b`)

## Typography

The typographic stack balances high-impact corporate executive presence with raw operational precision:

- **Headlines (Plus Jakarta Sans):** Geometric yet friendly contours optimized with tight negative letter tracking to give section titles a confident, technological gravitas.
- **Body & Explanatory Prose (Inter):** Highly legible, neutral workhorse that delivers fatigue-free readability across dense operations guides and policy dialogs.
- **Data, KPIs & Telemetry (JetBrains Mono):** Monospaced alignment enforces ledger stability across rapidly changing numbers—such as live GPS coordinates, vehicle registration IDs (`VH-0142`), trip timestamps, and latency calculations (`< 400ms`).

### Numeric & Eyebrow Styling
Superheads and category identifiers (e.g., `01 CUSTOMER MANAGEMENT`) must always be rendered in `eyebrow-badge` using uppercase monospaced text to anchor reader scannability across multi-tier workflow modules.

## Layout & Spacing

The layout is built upon a 12-column fluid grid system engineered for modular command panels and responsive monitoring dashboards.

### Responsive Breakpoints & Fluid Columns
- **Desktop (≥ 1280px):** 12 columns with `1.5rem` (`24px`) gutters and `2rem` (`32px`) lateral margins. Facilitates 4-column portal architectures (Customer, Driver, Vendor, Admin) and 8-step pipeline telemetry views.
- **Tablet (768px – 1279px):** 8 columns with `1rem` (`16px`) gutters. Telemetry blocks collapse into 2-by-2 modular matrices.
- **Mobile (< 768px):** 4 columns with `0.75rem` (`12px`) gutters and `1rem` safe margins. Sequential lists reflow vertically into touch-friendly accordion cards.

### Spacing Rhythm
Component padding adheres to a strict 4px/8px rhythm. Compact operational blocks (data logs, pill badges, and table rows) utilize `space-xs` and `space-sm`, while top-level structural containers utilize `space-xl` to prevent visual fatigue amidst dense content.

## Elevation & Depth

Visual hierarchy uses frosted glassmorphism anchored on deep obsidian planes, replacing standard drop shadows with crisp border illuminations and subtle luminous ambient blurs.

### Surface Tiers
1. **Tier 0 (Canvas Base):** Solid obsidian (`#0a0f18`) with a faint radial noise gradient.
2. **Tier 1 (Modular Glass Panels):** `rgba(15, 23, 42, 0.70)` with `backdrop-filter: blur(16px)` and a subtle `1px` top/border highlight of `rgba(255, 255, 255, 0.08)`.
3. **Tier 2 (Floating Cockpit Overlays & Steppers):** `rgba(30, 41, 59, 0.85)` with `backdrop-filter: blur(24px)` and low-opacity cyan/emerald directional rim lighting (`box-shadow: 0 8px 32px -4px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.1)`).
4. **Tier 3 (Active Driver Alert Takeovers & Dialogs):** Solid elevated obsidian (`#1e293b`) with dual ambient aura: an outer 24px diffused glow using the primary brand token (`rgba(16, 185, 129, 0.15)`).

### Lighting Contours
Cards do not use muddy drop shadows. Instead, visual separation is achieved via `1px` translucent hair-lines that capture light from the top-left, paired with dark ambient under-shadows (`rgba(0, 0, 0, 0.5)`).

## Shapes

The design system employs a refined geometric curve scale (Category 2: Rounded) that strikes an exact balance between modern software ergonomics and structural technical precision.

- **Micro Controls & Status Pills (`rounded-full`):** All lifecycle badges (`Assigned`, `En Route`, `Radar Active`) and tabular status tags are rendered with fully rounded pill boundaries for maximum scanning differentiation.
- **Interactive Buttons & Input Fields (`rounded-md` - 8px):** Form fields, action buttons, and dropdown triggers utilize an 8px radius to preserve snappy, responsive boundaries.
- **Card Containers & Cockpit Panels (`rounded-xl` - 16px):** Dashboard blocks, map overlays, and feature cards adopt a 16px radius, softening the high data density of the dark interface.

## Components

### Buttons & Interactive Triggers
- **Primary CTA:** Solid Emerald (`#10b981`) background, deep slate text (`#0a0f18`, `fontWeight: 600`), and a micro-glow border (`box-shadow: 0 0 20px -3px rgba(16, 185, 129, 0.4)`). On hover, brightness scales by 10% with a sub-pixel transform (`translateY(-1px)`).
- **Secondary / Telemetry Action:** Glass panel background (`rgba(255, 255, 255, 0.04)`), crisp 1px hairline border (`rgba(255, 255, 255, 0.12)`), text color in pure slate (`#f8fafc`). Hover reveals a subtle cyan border glow.
- **External Portal Trigger:** Features the trailing diagonal vector (`↗`) with a perpetual micro-indicator pulse dot.

### Status Indicators & Pulse Badges
- **Live Stream Badge:** Compact pill containing a dual-ring animated dot. Core dot is solid crimson or emerald (`6px`), wrapped in a continuous radiating ping ring (`animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite`).
- **Trip Lifecycle Badge:** Colored border (`1px`) paired with a 10% opacity matching fill tint. Monospaced uppercase text with an explicit glyph indicator (`● Searching`, `✓ Completed`).

### Data Tables & Dispatch Logs
- **Header:** Sticky obsidian bar, uppercase micro-typography (`JetBrains Mono`, 11px), subtle bottom border divider.
- **Row Architecture:** Alternate row backgrounds with a faint translucent wash (`rgba(255, 255, 255, 0.015)`). Hovering highlights the row in `rgba(6, 182, 212, 0.05)` with an emerald hairline indicator on the active edge. Numeric and currency columns (`₹405.00`) are strictly right-aligned and monospaced.

### Input Fields & Search Bars
- **Container:** Dark inset background (`#0f172a`), 1px border (`rgba(255, 255, 255, 0.1)`), height `44px`, text color `#f8fafc`.
- **Focus State:** Border transitions instantaneously to Telemetry Cyan (`#06b6d4`), accompanied by a soft `3px` ambient cyan ring (`rgba(6, 182, 212, 0.2)`).
- **Quick Command Indicator:** Suffix badge styled as an inset keycap (`/`) rendered in `JetBrains Mono`.

### Cards & Modular Panels
- **Telemetry Feature Card:** Features a sequential numeric label (`01` through `10`) in the top right corner rendered in low-opacity tabular mono. Hovering the card activates a gentle directional teal gradient along the top border (`background: linear-gradient(90deg, #10b981, #06b6d4)`).
- **Floating HUD Overlay:** High-blur glass container (`backdrop-filter: blur(24px)`) positioned over map surfaces, displaying driver telemetry, ETA countdowns, and real-time vehicle identifiers.